class Player {
  final String name;
  final String gender;

  Player({required this.name, required this.gender});
}
